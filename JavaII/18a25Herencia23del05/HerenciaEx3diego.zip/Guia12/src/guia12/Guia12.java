/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
Hotel4Estrellas hotel2 = new Hotel4Estrellas('A', "Restaurante XYZ", 50, 150, 250, 15, 120, "Hotel XYZ", "Calle Secundaria 456", "Ciudad ABC", "Jane Smith");
Hotel5Estrellas hotel3 = new Hotel5Estrellas(5, 10, 3, 'B', "Restaurante 5 Estrellas", 100, 200, 300, 20, 150, "Hotel 5 Estrellas", "Avenida Principal 789", "Ciudad XYZ", "John Smith");
Campings camping1 = new Campings(50, 20, true, false, 500.0, "Camping ABC", "Camino Rural 123", "Ciudad XYZ", "John Doe");
Residencias residencia1 = new Residencias(50, true, true, false, 1000.0, "Residencia XYZ", "Calle Principal 456", "Ciudad ABC", "Jane Smith");
Hotel4Estrellas hotel5 = new Hotel4Estrellas('B', "Restaurante ABC", 40, 120, 180, 10, 100, "Hotel PQR", "Avenida Secundaria 789", "Ciudad ABC", "Jane Smith");
Hotel5Estrellas hotel6 = new Hotel5Estrellas(3, 5, 2, 'A', "Restaurante 5 Estrellas", 80, 150, 250, 15, 200, "Hotel XYZ", "Camino Rural 123", "Ciudad XYZ", "John Smith");
Campings camping2 = new Campings(100, 20, true, false, 500.0, "Camping ABC", "Calle Principal 123", "Ciudad XYZ", "John Doe");
Campings camping3 = new Campings(80, 10, false, true, 300.0, "Camping XYZ", "Calle Secundaria 456", "Ciudad ABC", "Jane Smith");
 */
package guia12;

import EjercicioExtra3Entidades.Alojamientos;
import EjercicioExtra3Entidades.Campings;
import EjercicioExtra3Entidades.Hotel4Estrellas;
import EjercicioExtra3Entidades.Hotel5Estrellas;
import EjercicioExtra3Entidades.Residencias;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *Realizar un sistema de consulta que le permite al usuario consultar por diferentes criterios:
• todos los alojamientos.
• todos los hoteles de más caro a más barato.
• todos los campings con restaurante
• todos las residencias que tienen descuento.
* 
 * @author nicol
 */
public class Guia12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        ArrayList<Alojamientos> listaAlojamiento = new ArrayList();
        
        listaAlojamiento.add(new Hotel4Estrellas('A', "Restaurante XYZ", 50, 150, 250, 15, 120, "Hotel XYZ", "Calle Secundaria 456", "Ciudad ABC", "Jane Smith"));
        listaAlojamiento.add(new Hotel5Estrellas(5, 10, 3, 'B', "Restaurante 5 Estrellas", 100, 200, 300, 20, 150, "Hotel 5 Estrellas", "Avenida Principal 789", "Ciudad XYZ", "John Smith"));
        listaAlojamiento.add(new Campings(50, 20, true, false, 500.0, "Camping ABC", "Camino Rural 123", "Ciudad XYZ", "John Doe"));
        listaAlojamiento.add(new Residencias(50, true, true, false, 1000.0, "Residencia XYZ", "Calle Principal 456", "Ciudad ABC", "Jane Smith"));
        listaAlojamiento.add(new Hotel4Estrellas('B', "Restaurante ABC", 40, 120, 180, 10, 100, "Hotel PQR", "Avenida Secundaria 789", "Ciudad ABC", "Jane Smith"));
        listaAlojamiento.add(new Hotel5Estrellas(3, 5, 2, 'A', "Restaurante 5 Estrellas", 80, 150, 250, 15, 200, "Hotel XYZ", "Camino Rural 123", "Ciudad XYZ", "John Smith"));
        listaAlojamiento.add(new Campings(100, 20, true, false, 500.0, "Camping ABC", "Calle Principal 123", "Ciudad XYZ", "John Doe"));
        listaAlojamiento.add(new Campings(80, 10, false, true, 300.0, "Camping XYZ", "Calle Secundaria 456", "Ciudad ABC", "Jane Smith"));
        
        String op= "s"; 
        while(op == "s"){
            
            System.out.println("Buesqueda que desea hacer: ");
            System.out.println("--------------------------");
            System.out.println("1. Ver todos los Alojamientos disponibles.");
            System.out.println("2. Ver todos los Hoteles del mas caro al mas barato");
            System.out.println("3. Ver todos los campings con restaurante");
            System.out.println("4. Ver todas las residencias que tienen descuentos");
            int busqueda = leer.nextInt();
            
            switch (busqueda) {
                case 1:
                    alojamientosDis(listaAlojamiento);
                    break;
                case 2:
                    todosHoteles();
                    break;
                case 3:
                    campConRest();
                    break;
                case 4:
                    resiConDesc();
                    break;
                default:
                    throw new AssertionError();
            }

        }
   
    }
    
    public static void alojamientosDis(ArrayList<Alojamientos> listaAlojamiento){
        
        for (Alojamientos object : listaAlojamiento) {
            if (object instanceof Hotel4Estrellas) {
                
                Hotel4Estrellas object1 = (Hotel4Estrellas) object;
                System.out.println(object1);
                continue;
            }
            
            if (object instanceof Hotel5Estrellas) {
                Hotel5Estrellas object1 = (Hotel5Estrellas) object;
                System.out.println(object1);
                continue;
            }
            
            if (object instanceof Campings) {
                Campings object1 = (Campings) object;
                System.out.println(object1);
                continue;
            }
            
            if (object instanceof Residencias) {
                Residencias object1 = (Residencias) object;
                System.out.println(object1);
                continue;
            }
            
        }
               
    }
    
    public static void todosHoteles(){
        
        
               
    }
    
    public static void campConRest(){
        
        
               
    }
     
    public static void resiConDesc(){
        
        
    }                
}
