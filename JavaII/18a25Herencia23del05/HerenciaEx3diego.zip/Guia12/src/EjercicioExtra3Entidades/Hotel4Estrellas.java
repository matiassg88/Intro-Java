/*
Hotel **** Cantidad de Habitaciones, Número de camas, Cantidad de Pisos, Gimnasio,
Nombre del Restaurante, Capacidad del Restaurante, Precio de las Habitaciones.
 */
package EjercicioExtra3Entidades;

import EjercicioExtra3Interfaz.precioHabitacion;

/**
 *
 * @author Diego
 */
public class Hotel4Estrellas extends Hoteles implements precioHabitacion {
    
    protected char tipoGimnasio;
    protected String nombreRestaurante;
    protected Integer capacidadRestaurante;

    public Hotel4Estrellas() {
    }

    public Hotel4Estrellas(char tipoGimnasio, String nombreRestaurante, Integer capacidadRestaurante, Integer cantHabitaciones, Integer numCamas, Integer cantidadPisos, Integer precioHabitaciones, String nombre, String direccion, String localidad, String nombreGerente) {
        super(cantHabitaciones, numCamas, cantidadPisos, precioHabitaciones, nombre, direccion, localidad, nombreGerente);
        this.tipoGimnasio = tipoGimnasio;
        this.nombreRestaurante = nombreRestaurante;
        this.capacidadRestaurante = capacidadRestaurante;
    }

    public char getTipoGimnasio() {
        return tipoGimnasio;
    }

    public void setTipoGimnasio(char tipoGimnasio) {
        this.tipoGimnasio = tipoGimnasio;
    }

    public String getNombreRestaurante() {
        return nombreRestaurante;
    }

    public void setNombreRestaurante(String nombreRestaurante) {
        this.nombreRestaurante = nombreRestaurante;
    }

    public Integer getCapacidadRestaurante() {
        return capacidadRestaurante;
    }

    public void setCapacidadRestaurante(Integer capacidadRestaurante) {
        this.capacidadRestaurante = capacidadRestaurante;
    }

    public int valorAgregadoRestaurante(){
        int valorAgregado = 0;
        
        if (capacidadRestaurante < 30){
            valorAgregado = 10;
        } else if (capacidadRestaurante >= 30) {
            valorAgregado = 30;
        } else if (capacidadRestaurante > 50){
            valorAgregado = 50;
        }
        return valorAgregado;
    }
    
    public int valorAgregadoGimnasio(){
        int valorGimnasio = 0;
        if (tipoGimnasio == 'A'){
            valorGimnasio = 50;
        } else if(tipoGimnasio == 'B'){
            valorGimnasio = 30;
        }
        return valorGimnasio;
    }
    

    
    
    @Override
    public double precioHabitacion() {
        /*El precio de una habitación debe calcularse de acuerdo con la siguiente fórmula:
          PrecioHabitación = $50 + ($1 x capacidad del hotel) + (valor agregado por restaurante) + (valor
          agregado por gimnasio) + (valor agregado por limosinas).*/
        double precioHabitacion = PRECIO + (1 * (cantHabitaciones * numCamas * cantidadPisos)) + valorAgregadoRestaurante();
        
        return precioHabitacion;
    }
    
    
    @Override
    public String toString() {
        return "Hotel4Estrellas{" + "tipoGimnasio=" + tipoGimnasio + ", nombreRestaurante=" + nombreRestaurante + ", capacidadRestaurante=" + capacidadRestaurante + super.getNombre() + '}' ;
    }
    
    
    
}
