/*
Para los Camping se indica la capacidad máxima de carpas, la cantidad de baños
disponibles y si posee o no un restaurante dentro de las instalaciones.
 */
package EjercicioExtra3Entidades;

/**
 *
 * @author Diego
 */
public class Campings extends Extrahoteleros{
    
    private Integer capacidadMaxCarpas;
    private Integer bañosDisponibles;
    private boolean restaurante;

    public Campings() {
    }

    public Campings(Integer capacidadMaxCarpas, Integer bañosDisponibles, boolean restaurante, boolean privado, Double superficie, String nombre, String direccion, String localidad, String nombreGerente) {
        super(privado, superficie, nombre, direccion, localidad, nombreGerente);
        this.capacidadMaxCarpas = capacidadMaxCarpas;
        this.bañosDisponibles = bañosDisponibles;
        this.restaurante = restaurante;
    }

    public Integer getCapacidadMaxCarpas() {
        return capacidadMaxCarpas;
    }

    public void setCapacidadMaxCarpas(Integer capacidadMaxCarpas) {
        this.capacidadMaxCarpas = capacidadMaxCarpas;
    }

    public Integer getBañosDisponibles() {
        return bañosDisponibles;
    }

    public void setBañosDisponibles(Integer bañosDisponibles) {
        this.bañosDisponibles = bañosDisponibles;
    }

    public boolean isRestaurante() {
        return restaurante;
    }

    public void setRestaurante(boolean restaurante) {
        this.restaurante = restaurante;
    }

    @Override
    public String toString() {
        return "Campings{" + "capacidadMaxCarpas=" + capacidadMaxCarpas + ", ba\u00f1osDisponibles=" + bañosDisponibles + ", restaurante=" + restaurante + '}';
    }
    
    
}
