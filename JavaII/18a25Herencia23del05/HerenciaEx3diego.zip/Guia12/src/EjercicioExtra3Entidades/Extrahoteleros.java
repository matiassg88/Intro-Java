/*
Por cada
Alojamiento Extrahotelero se indica si es privado o no, así como la cantidad de metros
cuadrados que ocupa.
 */
package EjercicioExtra3Entidades;

/**
 *
 * @author Diego
 */
public class Extrahoteleros extends Alojamientos {
    
    protected boolean privado;
    protected Double superficie;

    public Extrahoteleros() {
    }

    public Extrahoteleros(boolean privado, Double superficie, String nombre, String direccion, String localidad, String nombreGerente) {
        super(nombre, direccion, localidad, nombreGerente);
        this.privado = privado;
        this.superficie = superficie;
    }

    public boolean isPrivado() {
        return privado;
    }

    public void setPrivado(boolean privado) {
        this.privado = privado;
    }

    public Double getSuperficie() {
        return superficie;
    }

    public void setSuperficie(Double superficie) {
        this.superficie = superficie;
    }

    @Override
    public String toString() {
        return "Extrahoteleros{" + "privado=" + privado + ", superficie=" + superficie + '}';
    }
    
    
}
