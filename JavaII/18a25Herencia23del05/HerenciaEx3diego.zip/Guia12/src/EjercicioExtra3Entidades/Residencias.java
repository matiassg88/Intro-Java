/*
Para las residencias se indica la cantidad de habitaciones, si se hacen o no descuentos 
a los gremios y si posee o no campo deportivo.
 */
package EjercicioExtra3Entidades;

/**
 *
 * @author Diego
 */
public class Residencias extends Extrahoteleros {
    
    private Integer cantidadHabitaciones;
    private boolean descuentosGremios;
    private boolean campoDeportivo;

    public Residencias() {
    }

    public Residencias(Integer cantidadHabitaciones, boolean descuentosGremios, boolean campoDeportivo, boolean privado, Double superficie, String nombre, String direccion, String localidad, String nombreGerente) {
        super(privado, superficie, nombre, direccion, localidad, nombreGerente);
        this.cantidadHabitaciones = cantidadHabitaciones;
        this.descuentosGremios = descuentosGremios;
        this.campoDeportivo = campoDeportivo;
    }

    public Integer getCantidadHabitaciones() {
        return cantidadHabitaciones;
    }

    public void setCantidadHabitaciones(Integer cantidadHabitaciones) {
        this.cantidadHabitaciones = cantidadHabitaciones;
    }

    public boolean isDescuentosGremios() {
        return descuentosGremios;
    }

    public void setDescuentosGremios(boolean descuentosGremios) {
        this.descuentosGremios = descuentosGremios;
    }

    public boolean isCampoDeportivo() {
        return campoDeportivo;
    }

    public void setCampoDeportivo(boolean campoDeportivo) {
        this.campoDeportivo = campoDeportivo;
    }

    @Override
    public String toString() {
        return "Residencias{" + "cantidadHabitaciones=" + cantidadHabitaciones + ", descuentosGremios=" + descuentosGremios + ", campoDeportivo=" + campoDeportivo + '}';
    }
    
    
}
