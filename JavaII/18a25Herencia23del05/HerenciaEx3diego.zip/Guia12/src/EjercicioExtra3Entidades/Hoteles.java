/*
Los Hoteles tienen como atributos: Cantidad de Habitaciones, Número de Camas, Cantidad de
Pisos, Precio de Habitaciones.
 */
package EjercicioExtra3Entidades;

/**
 *
 * @author Diego
 */
public class Hoteles extends Alojamientos {
    
    protected Integer cantHabitaciones;
    protected Integer numCamas;
    protected Integer cantidadPisos;
    protected Integer precioHabitaciones;

    public Hoteles() {
    }

    public Hoteles(Integer cantHabitaciones, Integer numCamas, Integer cantidadPisos, Integer precioHabitaciones, String nombre, String direccion, String localidad, String nombreGerente) {
        super(nombre, direccion, localidad, nombreGerente);
        this.cantHabitaciones = cantHabitaciones;
        this.numCamas = numCamas;
        this.cantidadPisos = cantidadPisos;
        this.precioHabitaciones = precioHabitaciones;
    }

    public Integer getCantHabitaciones() {
        return cantHabitaciones;
    }

    public void setCantHabitaciones(Integer cantHabitaciones) {
        this.cantHabitaciones = cantHabitaciones;
    }

    public Integer getNumCamas() {
        return numCamas;
    }

    public void setNumCamas(Integer numCamas) {
        this.numCamas = numCamas;
    }

    public Integer getCantidadPisos() {
        return cantidadPisos;
    }

    public void setCantidadPisos(Integer cantidadPisos) {
        this.cantidadPisos = cantidadPisos;
    }

    public Integer getPrecioHabitaciones() {
        return precioHabitaciones;
    }

    public void setPrecioHabitaciones(Integer precioHabitaciones) {
        this.precioHabitaciones = precioHabitaciones;
    }

   
    @Override
    public String toString() {
        return "Hoteles{" + "cantHabitaciones=" + cantHabitaciones + ", numCamas=" + numCamas + ", cantidadPisos=" + cantidadPisos + ", precioHabitaciones=" + precioHabitaciones + '}';
    }
    
    
}
