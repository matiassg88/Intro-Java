/*
Hotel ***** Cantidad de Habitaciones, Número de camas, Cantidad de Pisos, Gimnasio,
Nombre del Restaurante, Capacidad del Restaurante, Cantidad Salones de
Conferencia, Cantidad de Suites, Cantidad de Limosinas, Precio de las Habitaciones.
 */
package EjercicioExtra3Entidades;

import EjercicioExtra3Interfaz.precioHabitacion;

/**
 *
 * @author Diego
 */
public class Hotel5Estrellas extends Hotel4Estrellas implements precioHabitacion {
    
    private Integer cantidadSalones;
    private Integer cantidadSuites;
    private Integer cantidadLimosinas;

    public Hotel5Estrellas() {
    }

    public Hotel5Estrellas(Integer cantidadSalones, Integer cantidadSuites, Integer cantidadLimosinas, char tipoGimnasio, String nombreRestaurante, Integer capacidadRestaurante, Integer cantHabitaciones, Integer numCamas, Integer cantidadPisos, Integer precioHabitaciones, String nombre, String direccion, String localidad, String nombreGerente) {
        super(tipoGimnasio, nombreRestaurante, capacidadRestaurante, cantHabitaciones, numCamas, cantidadPisos, precioHabitaciones, nombre, direccion, localidad, nombreGerente);
        this.cantidadSalones = cantidadSalones;
        this.cantidadSuites = cantidadSuites;
        this.cantidadLimosinas = cantidadLimosinas;
    }

    public Integer getCantidadSalones() {
        return cantidadSalones;
    }

    public void setCantidadSalones(Integer cantidadSalones) {
        this.cantidadSalones = cantidadSalones;
    }

    public Integer getCantidadSuites() {
        return cantidadSuites;
    }

    public void setCantidadSuites(Integer cantidadSuites) {
        this.cantidadSuites = cantidadSuites;
    }

    public Integer getCantidadLimosinas() {
        return cantidadLimosinas;
    }

    public void setCantidadLimosinas(Integer cantidadLimosinas) {
        this.cantidadLimosinas = cantidadLimosinas;
    }

        public int valorAgregadoLimosinas(){
 
        int valorLimosinas = 15 * cantidadLimosinas;
        return valorLimosinas;
    }
        
    @Override
    public double precioHabitacion() {
        return super.precioHabitacion()+valorAgregadoLimosinas();
    }

    
  
    @Override
    public String toString() {
        return "Hotel5Estrellas{" + "cantidadSalones=" + cantidadSalones + ", cantidadSuites=" + cantidadSuites + ", cantidadLimosinas=" + cantidadLimosinas + '}';
    }
    
    
}
